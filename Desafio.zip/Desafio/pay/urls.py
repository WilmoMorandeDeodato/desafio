from django.conf.urls import url
from . import views
app_name='pay'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^novo-usuário/$', views.user_register, name='user_register'),
]
