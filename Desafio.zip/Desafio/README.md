## Seja bem-vindo/a ao Pay.

_Esta é uma web app proposta em um desafio da Pixel Infinito._

As tecnologias usadas para o desenvolvimento foram Python, Django para o backend, a API PayString para registar e setar dados do usuário e Materialize para o frontend.

## Passos para o deployment da Pay:

Nota: é importante escolher se vai instalar um [servidor local](https://docs.paystring.org/getting-started-local) ou vai usar o [sandbox](https://paystring.org/sandbox/) da PayString

- Instalar [python3](https://www.python.org/)
- Instalar, criar e activar [virtualenv](https://docs.python.org/3/tutorial/venv.html)
- Rodar o `requirements.txt` que se encontra no directório root da app usando o comando `pip install -r requirements.txt`
- Liga o servidor e starta a app usando o comando `python3 manage.py runserver`
