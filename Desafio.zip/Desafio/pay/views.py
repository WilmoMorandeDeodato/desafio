from django.shortcuts import render, get_object_or_404
from django.contrib import messages
from django.urls import reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template,render_to_string
from .models import *
from weasyprint.fonts import FontConfiguration
from weasyprint import HTML, CSS
import requests
import json
from json import JSONEncoder


def index(request):
    template_name = "index.html"
    user, pay_dict, addresses_dict, details_dict = '','','',''
    try:
        if request.method == 'POST':
            user = request.POST.get('user')
            url = "https://paystring.org/sandbox/users/"+ user +"$bot.sandbox.paystring.org"
            payload={}
            headers = {
              'PayID-API-Version': '2020-06-18',
              'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImM0MTIwYzE5ODlhNWQzNmQxZjAxODQxYjM5YTVmNjE3NTM4ZTk2M2I1NDFmMTBmODRmYjExNzQ5YjEzOTQ3YjkifQ.eyJqdGkiOiJhYmEyYzNhOC0xNTRlLTQ5MWMtODNhNS1hZWU5NGM5NzVlNGEiLCJzdWIiOiI5NDk1MzM1NC01NTY0LTQ5YTQtYWVlNi03NjM5MGRlNmMwZjQiLCJpZCI6Ijk0OTUzMzU0LTU1NjQtNDlhNC1hZWU2LTc2MzkwZGU2YzBmNCIsImdpdGh1YklkIjoiNDczMDM5MjEiLCJzYW5kYm94SWQiOiJhMGNhZmJjNC0xYmJkLTQ2ZDUtOTgwYy0xM2EwZjFlNzAyYmMiLCJhdXRoVHlwZSI6InRva2VuIiwiaWF0IjoxNjM4Mzc5OTIwLCJhdWQiOiJodHRwczovL3BheXN0cmluZy5vcmcvc2FuZGJveCIsImlzcyI6Imh0dHBzOi8vcGF5c3RyaW5nLm9yZy9zYW5kYm94LyJ9.inY1OpDxJDmt8sI3q6OHOM-l4E-S8dxmgI2FtFAIgZtHdHSpRUV_qR2uohspUcJOcCEeIwlfKT4evuWl3gORSW3qCx4gcb_ObvZYfmh4fTRjRlRJnl8TaTKVa5X432GrnpaQIDjDutkYb2LCytwc7Q7VoxHrw3dzxXF63NRzLNu6AKezjl-IIxlSn8xcM-kT3YSBwCJA4lpxzqrvxUM1dLiiehbO0FzctQWd-hq2ei8w6kjViFnUjy0pwyoTVtbXnAZ4SbUW_MbAOR5SrTJpbB2CRQ_VqDPRNm7cxQTNCOq12YaoOUPm_5hyRqKvKzedDbzmVfJoiwmyJiZpXXa6H9Dn-dBEmPsnFCh_yEkbEDfiUWBm7GMFoVoonmk74A4UidqWALblESAm7ZM125RUlcHj-LGTERTTxfA7Qomr1HCy2WLMRDISxVo0kmrUC-Ip0MNAITk9yT925R85wLtoKWBdrgsVGizVBrQWXI0XeNSJJgEryUpE_1vMPhvN9exMO0NoYpJYi_Isjz7CgpYrIu4RE8RSkQ_8jDH4Ejy1SwQC6sdArP8n22E8C1VmTo9nyT2o6v8gCdndw5nKB_49zv6LBksNvLCwApAy4UjVlWertZBrL1UWwkhkmngjJlYRTMRHBR2gzNMm4DuXPxk38M0wSxGJJFllLT-ZzmWakkU'
            }
            pay_JSON = requests.request("GET", url, headers=headers, data=payload)
            pay_dict = json.loads(pay_JSON.text)
            addresses_JSON = json.dumps(pay_dict["addresses"])
            addresses_dict = json.loads(addresses_JSON.replace("[", " ").replace("]", " "))
            details_JSON = json.dumps(addresses_dict["details"])
            details_dict = json.loads(details_JSON)
            if pay_JSON.ok:
                messages.success(request, 'Olá '+ user + ' suas informações foram carregadas com sucesso!')
            else:
                messages.error(request, 'Ocorreu um erro, não conseguimos encontrar usuário!')
                return render(request, template_name)
    except Exception as e:
        pay_dict = ""
        messages.error(request, 'Ocorreu um erro, não conseguimos encontrar usuário!')
    context = {
    'user':user,
    'pay_dict':pay_dict,
    'addresses_dict':addresses_dict,
    'details_dict':details_dict,
    }
    return render(request, template_name, context)


def user_register(request):
    template_name = "user-register.html"
    try:
        if request.method == 'POST':
            user = request.POST.get('user')
            network = request.POST.get('network')
            address = request.POST.get('address')
            environment = request.POST.get('environment')
            url = "https://paystring.org/sandbox/users"
            payload = json.dumps({
              "payId": user+"$bot.sandbox.paystring.org",
              "addresses": [
              {
                "paymentNetwork": network,
                "environment": environment,
                "details": {
                  "address": address
                }
              }
            ],
            })
            headers = {
              'PayID-API-Version': '2020-08-25',
              'Content-Type': 'application/json',
              'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImM0MTIwYzE5ODlhNWQzNmQxZjAxODQxYjM5YTVmNjE3NTM4ZTk2M2I1NDFmMTBmODRmYjExNzQ5YjEzOTQ3YjkifQ.eyJqdGkiOiJhYmEyYzNhOC0xNTRlLTQ5MWMtODNhNS1hZWU5NGM5NzVlNGEiLCJzdWIiOiI5NDk1MzM1NC01NTY0LTQ5YTQtYWVlNi03NjM5MGRlNmMwZjQiLCJpZCI6Ijk0OTUzMzU0LTU1NjQtNDlhNC1hZWU2LTc2MzkwZGU2YzBmNCIsImdpdGh1YklkIjoiNDczMDM5MjEiLCJzYW5kYm94SWQiOiJhMGNhZmJjNC0xYmJkLTQ2ZDUtOTgwYy0xM2EwZjFlNzAyYmMiLCJhdXRoVHlwZSI6InRva2VuIiwiaWF0IjoxNjM4Mzc0MTc2LCJhdWQiOiJodHRwczovL3BheXN0cmluZy5vcmcvc2FuZGJveCIsImlzcyI6Imh0dHBzOi8vcGF5c3RyaW5nLm9yZy9zYW5kYm94LyJ9.rtvATb21ygnIS22mKPHeUmkBKAU89uinJ0J_bIZAFDVkhT_RJZ5_Bw5Tkvr2DiHxxiNZpw8Dt08XSamt6C8xDKyZYYiiwuXmR8_f9waCWxWz-bDEA7CdKaWj8wMRl_kFu5s2_lil1_ZVp8BiY7rpBJ9CqenLvgEe7qruCmBLXE848RgK7a1jaXpxv6m6vLAQYu4Y_VzCY6woLuosTNVQUldY3FGJChTtGmW4WhYDgR_HT_d4Y8na4zTU2Oourh_IspclXwJixpWam9Ax_7vJfe_Tapr9HgXaBktNUnpiCcS1_gXsL9sikIkYPeDq2Axw-ap2W5gepQOEwN01LYa8TN4FV04s20R2Hi-F5Yo3zN_ssInS9DKKv5xKcIaedGno4kCVMKEiKt0NNq_UDhfmULKVWd6X4HkFmzuZHtnFLx-OxvKvO-PLorWfjcA6FkkSqpCDSTvNeJWSLLL7mKfxnzBGg6m7n3Ei534qfC2KKwbJXEdKOxouhOqI6s4-bq8U-Yi0fT94a02tYqqGUHYvKkoPULOV_no5BdYN62pLj3ugwMZ_BqoipCMvFdi8hWr7QtxGLbtGjxKH0jALn5ivfjGzXD7zZ7DV1JiLlf2jFaqj1PcHezbJAiPdhc_dpA5XFX7ZyooZ1EafTVVvGNH3akFCaHGE5TV40UczdZ3culI'

            }
            response = requests.request("POST", url, headers=headers, data=payload)
            if response.ok:
                messages.success(request, 'Sua conta foi criada com sucesso '+ user + ' seja bem-vindo/a!')
                messages.info(request, 'Caso queira saber mais sobre sua conta pesquise logo abaixo')
                return HttpResponseRedirect(reverse("pay:index"))
            else:
                messages.error(request, 'Ocorreu um erro, não conseguimos cria a sua conta!')
                return render(request, template_name)
    except Exception as e:
        messages.error(request, 'Ocorreu um erro, por favor volte a tentar em alguns instantes!')
    context = { }
    return render(request, template_name, context)
